$(document).ready(function(){
	$.each($( '.wysiwyg' ), function(i, v){
		var editor = CKEDITOR.replace( v );
	});
});